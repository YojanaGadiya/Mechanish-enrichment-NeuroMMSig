# Mechanish-enrichment-NeuroMMSig
Lab course for Mechanism enrichment of NeuroMMSig
